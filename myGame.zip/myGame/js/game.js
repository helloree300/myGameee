class Game{
    constructor(){

    }
    getState() {
        var gameStateRef = database.ref('gameState');
        gameStateRef.on("value", function (data) {
            gameState = data.val();
        })

    }

    update(state) {
        database.ref('/').update({
            gameState: state
        });
    }
    async start() {
            if (gameState === 0) {
                player = new Player();
                var playerCountRef = await database.ref('playerCount').once("value");
                if (playerCountRef.exists()) {
                    playerCount = playerCountRef.val();
                    player.getCount();
                }
                form = new Form()
                form.display();
            }
        }
    
    
    player1 = createSprite(displayWidth-100,200,40,40);
    //car1.addImage("car1",car1_img);
    player2 = createSprite(100,200,40,40);
    //car2.addImage("c2",car2_img);
    //cars = [player1, player2];

    play(){
    
    form.hide()
    Player.getPlayerInfo()
    if (allPlayers !== undefined) {
    var x1=displayWidth-100
    var y1=200
    var x2=100
    var y2=200
    writePosition(x1,y1);
    writePosition(x2,y2);
    background(back_img2);
    earth=createSprite(100,displayHeight-100,40,50);
    earth.addImage(earth_img);
    earth.scale=0.3
    drawSprites();
    }
  }
  updatePosition(){
    if(keyDown(LEFT_ARROW)){
        writePosition(-10,0);
    }
    else if(keyDown(RIGHT_ARROW)){
        writePosition(10,0);
    }
    else if(keyDown(UP_ARROW)){
        writePosition(0,-10);
    }
    else if(keyDown(DOWN_ARROW)){
        writePosition(0,+10);
    }
  }
   writePosition(x,y){
    //ball.x = ball.x + x;
    //ball.y = ball.y + y;

    database.ref("players/"+player.index).set({
        xPosition:xPosition+x,
        yPosition:yPosition+y,    
    })
   }
    readPosition(data){
    var position = data.val()

    }

    


}