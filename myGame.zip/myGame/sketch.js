var database;
var back_img;
var gameState =0;
var playerCount = 0;
var allPlayers;
var spaceship;
var earth
var player, form,game;
var player1,player2,players
var background

function preload(){
  back_img = loadImage("images/background.jpg");
  back_img2 = loadImage("images/background2.JPEG");
  earth_img=loadImage("images/earth.PNG");
  meteor_img=loadImage("images/meteor.PNG");
  spaceship_img=loadImage("images/spaceship.PNG");
  telescopes_img=loadImage("images/telescopes.PNG");
}
function setup() {
  createCanvas(displayWidth,displayHeight);
  database = firebase.database();
  game = new Game();
  game.getState();
  game.start();
}

function draw() {
  //background(back_img);
  
  

   if (playerCount === 2) {
     game.update(1);
   }
   if (gameState === 1) {
     clear(); 
     game.play();
   }
   if (gameState === 2) {
    
     game.end();
   }
}

